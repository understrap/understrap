<?php

require get_template_directory() . '/inc/widgets/functions/categories.php';
require get_template_directory() . '/inc/widgets/functions/archive.php';
require get_template_directory() . '/inc/widgets/functions/meta.php';
require get_template_directory() . '/inc/widgets/functions/tag-cloud.php';
require get_template_directory() . '/inc/widgets/functions/rss.php';

require get_template_directory() . '/inc/widgets/functions/class-walker-category.php';
require get_template_directory() . '/inc/widgets/functions/pages.php';
require get_template_directory() . '/inc/widgets/functions/class-walker-page.php';
require get_template_directory() . '/inc/widgets/functions/class-widget-nav-walker.php';
