<?php
/**
 * Blank content partial template.
 *
 * @package befluid
 */

the_content();
