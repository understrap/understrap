<?php
/**
 * Content empty partial template.
 *
 * @package befluid
 */

the_content();
